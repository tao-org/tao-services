/*
 * Copyright (C) 2017 CS ROMANIA
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 3 of the License, or (at your option)
 * any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, see http://www.gnu.org/licenses/
 */

package ro.cs.tao.wps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;
import ro.cs.tao.services.commons.ServiceLauncher;
import ro.cs.tao.services.commons.menu.Section;
import ro.cs.tao.services.commons.menu.ServiceEntry;
import ro.cs.tao.services.commons.menu.Visibility;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Cosmin Cara
 */
@SpringBootApplication()
@ImportResource({"classpath:tao-web-processing-service-context.xml"})
public class WPSLauncher extends ServiceLauncher {

    public static void main(String[] args) {
        SpringApplication.run(WPSLauncher.class, args);
    }

    public WPSLauncher() {
        super();
    }

    @Override
    public String serviceName() { return "Web Processing Service"; }

    @Override
    protected List<ServiceEntry> exportedEntries() {
        final List<ServiceEntry> entries = new ArrayList<>();
        entries.add(new ServiceEntry("Remote Services", "my/remoteServices", "./fragments/remoteServices-components.fragment.html", new Visibility[] { Visibility.USER, Visibility.ADMIN }, Section.WORKFLOWS, 2));
        entries.add(new ServiceEntry("Remote Web Services", "admin/remoteServices", "./fragments/remoteServices-admin2.fragment.html", new Visibility[] { Visibility.ADMIN }, Section.ADMINISTRATION, 5));
        return entries;
    }
}
