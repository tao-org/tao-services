/*
 * Copyright (C) 2018 CS ROMANIA
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 3 of the License, or (at your option)
 * any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, see http://www.gnu.org/licenses/
 */

package ro.cs.tao.services.orchestration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;
import ro.cs.tao.services.commons.ServiceLauncher;

/**
 * @author Cosmin Cara
 */
@SpringBootApplication()
@ImportResource({"classpath:tao-orchestration-services-context.xml"})
public class OrchestratorLauncher extends ServiceLauncher {

    public static void main(String[] args) {
        SpringApplication.run(OrchestratorLauncher.class, args);
    }

    public OrchestratorLauncher() {
        super();
    }

    @Override
    public String serviceName() { return "Orchestration Service"; }
}
